#!/bin/bash
NAME="django_ataskaitos"
DJANGODIR=/srv/sites/django_ataskaitos
SOCKFILE=/usr/local/virtualenvs/django_ataskaitos/run/gunicorn.sock
USER=deploy
GROUP=sudo
NUM_WORKERS=4
DJANGO_SETTINGS_MODULE=truckm.settings
DJANGO_WSGI_MODULE=truckm.wsgi


cd $DJANGODIR
source /usr/local/virtualenvs/django_ataskaitos/bin/activate
export DJANGO_SETTINGS_MODULE=$DJANGO_SETTINGS_MODULE
export PYTHONPATH=$DJANGODIR:$PYTHONPATH

RUNDIR=$(dirname $SOCKFILE)
test -d $RUNDIR || mkdir -p $RUNDIR

exec gunicorn ${DJANGO_WSGI_MODULE}:application \
  --name $NAME \
  --workers $NUM_WORKERS \
  --user=$USER --group=$GROUP \
  --bind=unix:$SOCKFILE \
  --log-level=debug \
  --log-file=-
