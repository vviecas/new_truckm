from django.shortcuts import render
from django.http import HttpResponse
import requests
import xlwt
import fdb as kinterbasdb
from datetime import datetime, date
import math



def dok_list(request,dt1=None,dt2=None,sndkod=None):
 if request.user.groups.filter(name='Truck Master').exists():
    if dt1 is None:
        today = date.today()
        first = date(day=1, month=today.month, year=today.year)
        dt1 = str(first)
        dt2 = str(date.today())
        sndkod = 'KANDEL V'
    kwargs = {}
    kwargs['data__range'] = ("%s-%s-%s" % (dt1[0:4], dt1[5:7], dt1[8:10]),
                             "%s-%s-%s" % (dt2[0:4], dt2[5:7], dt2[8:10]))

    context = {
        "nuo": dt1[:10],
        "iki": dt2[:10],
     }

    if 'nuo' and 'iki' and 'sndkod' in request.GET:
        dt1 = request.GET['nuo']
        dt2 = request.GET['iki']
        sndkod = request.GET['sndkod']

    con = kinterbasdb.connect(dsn='firebird-pc.latgrupe.eu:TruckM', user='sysdba', password='masterkey', charset='WIN1257')
    cur = con.cursor()

    cur.execute("""select id_snd,trim(kod) kod,pavad from snd where gr='PARDAVIMAI' order by id_snd""")
    snd_list = []
    for row in cur.fetchall():
        p = {'id_snd': row[0], 'kod': row[1], 'pavad': row[2]}
        # p.num_responses = row[0]
        snd_list.append(p)

    cur.execute("""select d.id_dok, d.data,d.doknr,s.pavad spavad,k.pavad kpavad,d.skola,d.apmsum,d.dok_user
                      from dok d inner join kl k on d.id_kl=k.id_kl inner join snd s on d.id_snd=s.id_snd
                      where (d.doktip=4) and (s.kod = ?) and (d.data between ? and ?)  order by d.data asc""",[sndkod,dt1,dt2])

    result_list = []
    for row in cur.fetchall():
        p = {'id': row[0], 'datad': row[1], 'doknr': row[2], 'spavad': row[3], 'kpavad': row[4], 'skola': row[5],
             'apmsum': row[6], 'dok_user': row[7]}
        # p.num_responses = row[2]
        result_list.append(p)
    return render(request, 'truckmpard.html', {'result_list': result_list,'nuo':dt1,'iki':dt2,'snd_list':snd_list,'sndkod':sndkod})
 else:
     return render(request, 'index.html')

def export_dok_xls(request,sndkod,nuo,iki):
 if request.user.groups.filter(name='Truck Master').exists():
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename="invoices.xls"'


    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('Invoices')

    # Sheet header, first row
    row_num = 0

    font_style = xlwt.XFStyle()
    font_style.font.bold = True

    columns = ['Date', 'Doc. No.',  'Warehouse', 'Customer', 'Amount', 'Paid', 'Responsible person',]

    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], font_style)

    # Sheet body, remaining rows
    font_style = xlwt.XFStyle()
    con = kinterbasdb.connect(dsn='firebird-pc.latgrupe.eu:TruckM', user='sysdba', password='masterkey', charset='WIN1257')
    cur = con.cursor()
    cur.execute("""select cast(cast(d.data as date) as varchar(10)),d.doknr,s.pavad spavad,k.pavad kpavad,d.skola,d.apmsum,d.dok_user
                            from dok d inner join kl k on d.id_kl=k.id_kl inner join snd s on d.id_snd=s.id_snd
                            where (d.doktip=4) and (s.kod = ?) and (d.data between ? and ?) order by d.data asc""",[sndkod,nuo,iki])
    for row in cur.fetchall():
         row_num += 1
         for col_num in range(len(row)):
             ws.write(row_num, col_num, row[col_num], font_style)

    wb.save(response)
    return response
 else:
     return render(request, 'index.html')


def get_dok(request, id, tip,doknr):

  if request.user.groups.filter(name='Truck Master').exists():
   result = requests.get('http://10.0.6.69:8080/datasnap/rest/TServerMethods1/getFile( %s,%s)' % (id, tip), auth=('GetFile', 'StUd[6\!x^DYA#5e'))
   response = HttpResponse(result," Content-type=application/pdf")
   filename = doknr+'.pdf'
   response['Content-Disposition'] = 'attachment; filename=%s'%filename

   return response
  else:
      return render(request, 'index.html')

def trmprk_list(request):
 if request.user.groups.filter(name='Terminal').exists():
    x = ''
    tx2 = ''
    dt=datetime.now()
    imone = request.user.first_name
    vartot = request.user.username
    idprk = -1
    uzskiek = 0
    uzskaina = 0
    count = 0
    con = kinterbasdb.connect(dsn='firebird-pc.latgrupe.eu:Luckust', user='sysdba', password='masterkey', charset='UTF8')
    if request.method == 'POST' and request.POST['uzskiekis']!='':
       kod = request.POST['product']
       uzskiek = float(request.POST['uzskiekis'])
       uzskaina = float(request.POST['uzskaina'])
       suma = uzskiek*uzskaina
       cur = con.cursor()
       cur.execute("""select kod from trmcart where customer=? and kod=?""",[imone,kod])
       for row in cur:
           count = 1
       if count == 0:
           cur.execute("""insert into trmcart (ID_trmcart, customer, kod, kiekis, kaina, suma,memo, vartot, modify_date,id_kladr) VALUES (GEN_ID(id_apv_gen,1), ?,?, ?,?,?,'',?,?,
                       (select first 1 id_trmadr from trmkladr where vartot=?)) """,[imone,kod,uzskiek,uzskaina,suma,vartot,dt,vartot])
       else:
        cur.execute("""update trmcart set kiekis=kiekis+?,suma=suma+(kaina*?) where kod=? and customer=?""",[ uzskiek,uzskiek,kod,imone])
       con.commit()

    if 'txt' in request.GET and request.GET['txt'] != '':
        tx = '%' + request.GET['txt'] + '%'
        x = request.GET['txt']
    else:
        tx = '%'
        tx2 = ' and (p.kiekis_1>0) '
    if request.user.groups.filter(name='Branch').exists():
        tx3 = ' and vartot=?'
    else:
        tx3 = ' and customer<>?'
    cur = con.cursor()
    cur.execute("""select  coalesce(count(id_trmcart),0) kiek,coalesce(sum(kiekis*kaina),0) suma from trmcart where customer=? """+tx3+"""  """,[imone,vartot])
    lcart = []
    for row in cur.fetchall():
        p = {'kiek': row[0],'suma':row[1]}
        lcart.append(p)

    cur.execute("""select p.KOD,c.pavad,c2.pavad as gamintojas, sum(p.kiekis_1)/count(p.kod) kiekis_cl,
     sum(coalesce((select sum(a1.likutis-a1.rezervuota) from trmapv a1 where a1.ID_TRMPRK=P.ID_TRMPRK and a1.optip=2 and a1.tip=0),0)) as kiekis,
     sum(coalesce((select sum(a1.likutis-a1.rezervuota) from trmapv a1 where a1.ID_TRMPRK=P.ID_TRMPRK and a1.optip=2 and a1.tip=0 and char_length(a1.muitkod_rf)>8),0)) as s,
     sum(coalesce((select sum(a1.likutis-a1.rezervuota) from trmapv a1 where a1.ID_TRMPRK=P.ID_TRMPRK and a1.optip=2 and a1.tip=0 and char_length(a1.muitkod_rf)<=8),0)) as r,
     sum(coalesce((select sum(a1.kiekis0) from trmapv a1 left join trmdok d1 on a1.id_trmdok=d1.id_trmdok where a1.ID_TRMPRK=P.ID_TRMPRK and a1.kiekis=0 and a1.OPTIP=2 and d1.sutvarkyta='N' and d1.data_iskr is null),0)) as atvyksta,
     p.price_ukr,p.price_partner,p.price_public,
     min((select first 1 cast(d1.data_pakr+60 as TIMESTAMP) from trmapv a1 left join trmdok d1 on a1.id_trmdok=d1.id_trmdok where a1.ID_TRMPRK=P.ID_TRMPRK and a1.kiekis=0 and a1.OPTIP=2 and d1.sutvarkyta='N' and d1.data_iskr is null)) as datatvyksta
     from TRMPRK P left join trmdict c on p.id_txt6=c.id_trmdict left join trmdict c2 on  p.id_gam=c2.id_trmdict 
     where p.aktyvi='Y' and p.tip=0 and upper(p.kod) like upper(?) """+tx2+"""
     group by  p.kod,c.pavad,c2.pavad,p.muitkod,p.price_ukr,p.price_partner,p.price_public
     order by p.kod""",[tx])
    result_list = []
    htm = 'trmprk.html'
    if request.user.groups.filter(name='Branch').exists():
        htm = 'trmprk_branch.html'
    for row in cur.fetchall():
        p = {'kod': row[0], 'pavad': row[1], 'gam': row[2], 'kiekiscl': row[3], 'kiekis': row[4], 'skiekis': row[5], 'rkiekis': row[6], 'atvyksta': row[7],
             'price_eur': row[8],'price_partner': row[9],'price_public': row[10],'datatvyksta': row[11], 'image': row[0]+'.jpg'}
        # p.num_responses = row[2]
        result_list.append(p)
    return render(request, htm, {'result_list': result_list,'q':x,'lcart':lcart,'kiek':''})
 else:
     return render(request, 'index.html')

def orders_admin(request,nuo=None,iki=None,idadr=None):
 if request.user.groups.filter(name='Admins').exists():
   if nuo is None:
         today = date.today()
         nuo = str(date.today())
   if iki is None:
         today = date.today()
         iki = str(date.today())
   if 'nuo' and 'iki' in request.GET:
       nuo = request.GET['nuo']
       iki = request.GET['iki']
   dt=datetime.now()
   dt2 = str(date.today())
   imone = request.user.first_name
   rkod = ''
   klpavad = ''
   vartot = request.user.username
   tx = ''
   if request.user.first_name == 'admin':
      tx = "where p.aktyvi='Y' and p.tip=? and ((d.DATA_PAKR between ? and ?) or (o.status<200))"
      imone=0
   else:
      tx = "where p.aktyvi='Y' and p.tip=0  and trim(k.rkod)=? and ((d.DATA_PAKR between ? and ?) or (o.status<1))"
   idprk = -1
   kodas = ''
   con = kinterbasdb.connect(dsn='firebird-pc.latgrupe.eu:Luckust', user='sysdba', password='masterkey', charset='UTF8')
   cur = con.cursor()
   con2 = kinterbasdb.connect(dsn='firebird-pc.latgrupe.eu:ClaraLux', user='sysdba', password='masterkey', charset='WIN1257')
   cur2 = con2.cursor()
   if request.method == 'POST' and request.POST['rezkiekis'] !='-1':
      idapv = int(request.POST['idapv'])
      iddok = int(request.POST['iddok'])
      rezkiekis = float(request.POST['rezkiekis'])
      doknr = request.POST['doknr']
      idprk = int(request.POST['idprk'])

      kiekis0 = rezkiekis
      kelyje = 0
      muitkodlt = ''
      muitkodrf = ''
      savikf = 0

      reserve(idapv, iddok, idprk, rezkiekis, vartot)

      # cur.execute("""select first 1 trim(k.rkod),trim(k.pavad) from trmkl k left join trmdok d on k.id_trmkl=d.id_kl where d.id_trmdok=? """, [iddok])
      # for row in cur.fetchall():
      #   rkod = row[0]
      #   klpavad = row[1]
      # cur.execute("""select first 1 kod from trmprk where id_trmprk=? """, [idprk])
      # for row in cur.fetchall():
      #   kodas = row[0]
      # cur.execute("""delete from trmapv where id_trmapvo=? and id_trmdok=? """,[idapv,iddok])
      # cur.execute("""update trmorder set kiekis1=0,kiekis2=0,kiekis3=0,kiekis4=0,status=0 where id_trmapv=? """, [idapv])
      # yra = 0
      # cur2.execute("""select first 1 id_prk from prk where trim(kod)=? """, [kodas])
      # for row2 in cur2.fetchall():
      #     yra = 1
      # if yra == 0:
      #     cur2.execute("""insert into prk (id_prk_rec,id_prk,kod,pavad,id_snd) values (GEN_ID(id_prk_rec_gen,1),GEN_ID(id_prk_gen,1),?,?,1345)""", [rkod, rkod])
      #
      # cur2.execute("""select coalesce(sum(abs(kiekis)),0) from apv where rectip='Y' and id_dok=(select first 1 id_dok from dok where trim(doknr)=? or trim(doknr2)=?)
      #              and id_prk=(select first 1 id_prk from prk where trim(kod)=?) """, [doknr,doknr,kodas])
      # for row2 in cur2.fetchall():
      #     if row2[0] == kiekis0 and kiekis0 > 0:
      #        cur.execute("""update trmorder set kiekis1=0,kiekis2=0,kiekis3=0,kiekis4=0,status=2 where id_trmapv=? """, [idapv])
      #        rezkiekis = 0
      #        kiekis0 = 0
      # if rezkiekis < 1/100000:
      #     cur2.execute("""delete from prk_rez where id_prk=(select first 1 id_prk from prk where trim(kod)=?) and id_sdok=(select first 1 id_sdok from sdok where trim(doknr)=?) """, [kodas,doknr])
      #     cur2.execute("""delete from spub2 where id_prk=(select first 1 id_prk from prk where trim(kod)=?) and id_sdok=(select first 1 id_sdok from sdok where trim(doknr)=?) """, [kodas,doknr])
      #     cur2.execute("""select id_sdok from spub2 where id_sdok=(select first 1 id_sdok from sdok where trim(doknr)=?) """, [doknr])
      #     yra = 0
      #     for row2 in cur2.fetchall():
      #        yra = 1
      #     if yra == 0:
      #        cur2.execute("""delete from sdok where trim(doknr)=? """, [doknr])
      #
      # cur2.execute("""select coalesce(sum(p1.kiekis),0)-coalesce(sum(r.kiekis),0),coalesce(avg(p.kn2),0) from prk1 p1 left join prk p on p1.id_prk=p.id_prk and p1.id_snd=p.id_snd left join prk_rez r on p.id_prk=r.id_prk and p.id_snd=r.id_snd
      #              where p1.kiekis>0 and p.kod=? and p.id_snd=1345 """,[kodas])
      # for row2 in cur2.fetchall():
      #   if rezkiekis <= row2[0]:
      #       rezkiekis = 0
      #       savikf = row2[1]
      #   else:
      #       rezkiekis = rezkiekis-row2[0]
      #       savikf = row2[1]
      #
      # if kiekis0 > 0:
      #     suma = (kiekis0 - rezkiekis) * savikf
      #     yra = 0
      #     cur2.execute("""select first 1 id_kl from kl where trim(rkod)=? """, [rkod])
      #     for row2 in cur2.fetchall():
      #         yra = 1
      #     if yra == 0:
      #         cur2.execute("""insert into kl (id_kl,rkod,kod,pavad) values (GEN_ID(id_kl_gen,1),?,?,?)""", [rkod,rkod,klpavad])
      #     cur2.execute("""select first 1 id_sdok from sdok where doknr=? """, [doknr])
      #     yra = 0
      #     sdok = -1
      #     for row2 in cur2.fetchall():
      #         yra = 1
      #         sdok = row[0]
      #     if yra == 0:
      #            cur2.execute("""insert into sdok (id_sdok,data,doknr,doktip,id_kl,id_snd,suma,sumviso,pvm,kurs,val,skola,sdok_user,uzsak) values (GEN_ID(id_dok_gen,1),?,?,4,coalesce((select first 1 id_kl from kl where trim(rkod)=?),-1),1345,?,?,?,1,'EUR',?,?,'Y')""",
      #                  [dt2,doknr,rkod,suma,suma,suma*1.21-suma,suma*1.21,vartot])
      #     cur2.execute("""insert into spub2 (id_rec,id_sdok,id_prk,id_snd,kiekis,parkn,pvmproc,pvm,vnt,uzs_prkkod) values (GEN_ID(id_apv_gen,1),GEN_ID(id_dok_gen,0),coalesce((select first 1 id_prk from prk where kod=? and id_snd=1345),-1),
      #                  1345,?,?,21,?,'vnt.',?)""", [kodas,kiekis0,savikf,suma*1.21-suma,kodas])
      #     cur2.execute("""insert into prk_rez (id,id_dok,id_sdok,id_prk,id_snd,kiekis,rez_type,author,terminas) values (GEN_ID(id_snd_gen,1),-1,GEN_ID(id_dok_gen,0),coalesce((select first 1 id_prk from prk where kod=? and id_snd=1345),-1),
      #                            1345,?,4,?,?+10)""", [kodas,kiekis0,vartot,dt])
      #
      #     cur.execute("""update trmorder set status=1, kiekis1=? where id_trmapv=? """, [kiekis0-rezkiekis,idapv])
      # if rezkiekis > 0:
      #     cur.execute("""select id_trmapv,abs(kiekis) from trmapv where id_trmapvo=? and abs(kiekis)>0 and char_length(muitkod_rf)>8""", [idapv])
      #     yra = 0
      #     for row in cur.fetchall():
      #         yra = 1
      #         if yra > 0:
      #             if rezkiekis >= row[1]:
      #                 cur.execute("""update trmorder set kiekis2=?, status=1 where id_trmapv=? """, [row[1],idapv])
      #                 rezkiekis = rezkiekis-row[1]
      #             else:
      #                 cur.execute("""update trmorder set kiekis2=?, status=1 where id_trmapv=? """, [rezkiekis, idapv])
      #                 rezkiekis = 0
      #     cur.execute("""select id_trmapv,abs(kiekis) from trmapv where id_trmapvo=? and abs(kiekis)>0 and char_length(muitkod_rf)<=8""", [idapv])
      #     yra = 0
      #     for row in cur.fetchall():
      #         yra = 1
      #         if yra > 0:
      #             if rezkiekis >= row[1]:
      #                 cur.execute("""update trmorder set kiekis3=?, status=1 where id_trmapv=? """, [row[1],idapv])
      #                 rezkiekis = rezkiekis-row[1]
      #             else:
      #                 cur.execute("""update trmorder set kiekis3=?, status=1 where id_trmapv=? """, [rezkiekis, idapv])
      #                 rezkiekis = 0
      #
      # yra = 0
      # while True and rezkiekis>0:
      #  lik = 0
      #  idapv0 = -1
      #  ipak = 1
      #  inspkiekis = 0
      #  cur.execute("""select first 1 a.id_trmapv0,a.kiekis,a.pkiekis,a.likutis-a.rezervuota,a.muitkod_lt,a.muitkod_rf from trmapv a left join trmprk p on a.id_trmprk=p.id_trmprk
      #              where char_length(a.muitkod_rf)>8 and p.kod=? and a.likutis-a.rezervuota>0 """, [kodas])
      #  for row in cur.fetchall():
      #    yra = 1
      #    idapv0 = row[0]
      #    lik = row[3]
      #    ipak = row[1]/row[2]
      #    muitkodlt = row[4]
      #    muitkodrf = row[5]
      #    if rezkiekis <= lik:
      #        inspkiekis = math.ceil(rezkiekis / ipak)
      #        kiekis4 = rezkiekis
      #    else:
      #        inspkiekis = math.ceil(lik / ipak)
      #        kiekis4 = lik
      #  if yra == 0:
      #      cur.execute(
      #          """select first 1 a.id_trmapv0,a.kiekis,a.pkiekis,a.likutis-a.rezervuota,a.muitkod_lt,a.muitkod_rf from trmapv a left join trmprk p on a.id_trmprk=p.id_trmprk
      #              where char_length(a.muitkod_rf)<=8 and p.kod=? and a.likutis-a.rezervuota>0 """, [kodas])
      #      for row in cur.fetchall():
      #          yra = 1
      #          idapv0 = row[0]
      #          lik = row[3]
      #          ipak = row[1]/row[2]
      #          muitkodlt = row[4]
      #          muitkodrf = row[5]
      #          if rezkiekis <= lik:
      #              inspkiekis = math.ceil(rezkiekis / ipak)
      #              kiekis4 = rezkiekis
      #          else:
      #              inspkiekis = math.ceil(lik / ipak)
      #              kiekis4 = lik
      #  if yra == 0:
      #      cur.execute(
      #          """select first 1 a1.id_trmapv0,a1.kiekis0,a1.pkiekis0,a1.kiekis0-a1.rezervuota,muitkod_lt,muitkod_rf from trmapv a1 left join trmdok d1 on a1.id_trmdok=d1.id_trmdok left join trmprk p on p.id_trmprk=a1.id_trmprk where p.kod=? and a1.kiekis=0 and a1.OPTIP=2 and d1.sutvarkyta='N'
      #          and d1.data_iskr is null and a1.kiekis0-a1.rezervuota>0 """, [kodas])
      #      for row in cur.fetchall():
      #          yra = 1
      #          idapv0 = row[0]
      #          lik = row[3]
      #          kelyje = lik
      #          kiekis4 = 0
      #          ipak = row[1]/row[2]
      #          muitkodlt = row[4]
      #          muitkodrf = row[5]
      #          if rezkiekis <= lik:
      #              inspkiekis = math.ceil(rezkiekis / ipak)
      #              kiekis4 = rezkiekis
      #          else:
      #              inspkiekis = math.ceil(lik / ipak)
      #              kiekis4 = lik
      #
      #  if inspkiekis > 0 and lik>0:
      #      cur.execute("""insert into trmapv (id_trmapv,id_trmapv0,id_trmprk,id_trmdok,id_trmapvo,kiekis0,pkiekis0,optip,vartot,muitkod_lt,muitkod_rf) values (GEN_ID(id_apv_gen,1),?,?,?,?,?,?,4,?,?,?) """,
      #              [idapv0,idprk,iddok,idapv,-inspkiekis*ipak,-inspkiekis,vartot,muitkodlt,muitkodrf])
      #      if len(muitkodrf)>8 and kelyje == 0:
      #          cur.execute("""update trmorder set status=1,kiekis2=kiekis2+? where id_trmapv=? """, [kiekis4,idapv])
      #      elif len(muitkodrf)<=8 and kelyje == 0:
      #          cur.execute("""update trmorder set status=1,kiekis3=kiekis3+? where id_trmapv=? """, [kiekis4, idapv])
      #      else:
      #          cur.execute("""update trmorder set status=1,kiekis4=kiekis4+? where id_trmapv=? """, [kiekis4, idapv])
      #
      #  if rezkiekis <= lik:
      #        rezkiekis = 0
      #  else:
      #        rezkiekis = rezkiekis - lik
      #  if yra == 0:
      #      rezkiekis = 0
      #  else:
      #      yra = 0
      #  if rezkiekis == 0:
      #      break
      #
      # con.commit()
      # con2.commit()
   if request.method == 'POST' and request.POST['rezkiekis'] == '-1':
      idapv = int(request.POST['idapv'])
      iddok = int(request.POST['iddok'])
      doknr = request.POST['doknr']
      yra = 0
      kodas = ''
      cur.execute("""select first 1 p.kod from trmprk p left join trmorder o on p.id_trmprk=o.id_trmprk where o.id_trmapv=? """, [idapv])
      for row in cur.fetchall():
          kodas = row[0]
      cur2.execute(
          """delete from prk_rez where id_prk=(select first 1 id_prk from prk where trim(kod)=?) and id_sdok=(select first 1 id_sdok from sdok where trim(doknr)=?) """,
          [kodas, doknr])
      cur2.execute(
          """delete from spub2 where id_prk=(select first 1 id_prk from prk where trim(kod)=?) and id_sdok=(select first 1 id_sdok from sdok where trim(doknr)=?) """,
          [kodas, doknr])
      cur2.execute(
          """select id_sdok from spub2 where id_sdok=(select first 1 id_sdok from sdok where trim(doknr)=?) """,
          [doknr])
      yra = 0
      for row2 in cur2.fetchall():
          yra = 1
      if yra == 0:
          cur2.execute("""delete from sdok where trim(doknr)=? """, [doknr])

      cur2.execute(
          """select id_dok from dok where doknr=? or doknr2=? """,  [doknr,doknr])
      yra = 0
      for row2 in cur2.fetchall():
          yra = 1
      if yra == 0:
          cur.execute("""select id_trmapv from trmorder where id_trmapv<>? and id_trmdok=? """, [idapv, iddok])
          for row in cur.fetchall():
              yra = 1

          if yra == 0:
              cur.execute("""delete from trmdok where id_trmdok=? """, [iddok])
          else:
              cur.execute("""delete from trmorder where id_trmapv=? """, [idapv])

      con.commit()
      con2.commit()
   x = ''
   tx2 = ''
   if 'txt' in request.GET and request.GET['txt'] != '':
       x = request.GET['txt']
       tx2 = '%' + x + '%'
   else:
       tx2 = '%'

   cur.execute("""select distinct d.eilnr,d.DATA_PAKR, p.KOD || ' ' || c.pavad item,o.kiekis0,
      coalesce(o.kiekis1+o.kiekis2+o.kiekis3+o.kiekis4,0) rez,
      o.status pdata,o.KAINA,o.kaina*o.KIEKIS0 suma,iif(o.STATUS<1,'Open',iif(o.status=200,'Invoiced','Execute')) status,k.pavad,o.id_trmapv,o.id_trmprk,d.id_trmdok
      ,o.kiekis1,iif(kiekis1>0,cast(cast('now' as date) as varchar(10)),'-') dt1  
      ,o.kiekis2,iif(kiekis2>0,iif(cast(cast('now' as date) as varchar(10))>cast(cast(o.modify_date as date)+5 as varchar(10)) ,cast(cast('now' as date) as varchar(10)),cast(cast(o.modify_date as date)+5 as varchar(10))),'-') dt2
      ,o.kiekis3,iif(kiekis3>0,iif(cast(cast('now' as date) as varchar(10))>cast(cast(o.modify_date as date)+7 as varchar(10)),cast(cast('now' as date) as varchar(10)),cast(cast(o.modify_date as date)+7 as varchar(10))),'-') dt3
      ,o.kiekis4,iif(kiekis4>0,cast((select first 1 cast(d1.data_pakr+60 as date) from trmapv a1 left join trmdok d1 on a1.id_trmdok=d1.id_trmdok where a1.ID_TRMPRK=o.id_trmprk and a1.kiekis=0 and a1.OPTIP=2 and d1.sutvarkyta='N' and d1.data_iskr is null) as varchar(10)),'-') dt4 
      ,o.id_kladr,k.id_trmkl,coalesce(r.kod,''),coalesce(r.adr,''),coalesce(r.pindex,''),coalesce(r.salis,''),o.pkiekis
      from trmdok d left join trmorder o on d.id_trmdok=o.id_trmdok left join trmprk p on p.id_trmprk=o.id_trmprk 
      left join trmdict c on p.id_txt6=c.id_trmdict left join trmkl k on k.ID_trmKL=d.ID_KL left join trmkladr r on o.id_kladr=r.id_trmadr          
      """+tx+""" and ( (upper(p.kod) like upper(?)) or (upper(k.pavad) like upper(?)) )order by o.id_trmapv""",[imone,nuo,iki,tx2,tx2])
   result_list = []
   viso_suma = 0
   for row in cur.fetchall():
      viso_suma =  viso_suma+row[7]
      p = {'nr': row[0], 'data': row[1], 'item': row[2], 'kiekis': row[3], 'rez': row[4], 'pdata': row[5], 'kaina': row[6], 'suma': row[7], 'status': row[8], 'klpavad':row[9], 'idapv':row[10], 'idprk':row[11],
           'iddok':row[12], 'kiekis1':row[13], 'dt1':row[14], 'kiekis2':row[15], 'dt2':row[16], 'kiekis3':row[17], 'dt3':row[18], 'kiekis4':row[19], 'dt4':row[20], 'uzskiekis':row[3]-row[4], 'id_kladr':row[21]
           , 'id_trmkl':row[22], 'adrkod':row[23], 'adr':row[24], 'index':row[25], 'salis':row[26], 'pkiekis':row[27]}
      result_list.append(p)


   return render(request, 'orders_admin.html', {'result_list': result_list, 'viso_suma': viso_suma,'nuo': nuo, 'iki': iki,'q':x})
 else:
     return render(request, 'index.html')

def orders(request,nuo=None,iki=None):
 if request.user.groups.filter(name='Terminal').exists():
   if nuo is None:
         today = date.today()
         nuo = str(date.today())
   if iki is None:
         today = date.today()
         iki = str(date.today())
   if 'nuo' and 'iki' in request.GET:
       nuo = request.GET['nuo']
       iki = request.GET['iki']
   dt=datetime.now()
   imone = request.user.username
   tx = ''
   # if request.user.first_name == 'admin':
   #    tx = "where p.aktyvi='Y' and p.tip=? and (d.DATA_PAKR between ? and ? or o.status<2)"
   #    imone=0
   if request.user.groups.filter(name='Branch').exists():
        tx = "where p.aktyvi='Y' and p.tip=0  and o.vartot=? and (d.DATA_PAKR between ? and ? or o.status<200)"
   else:
       imone = request.user.first_name
       tx = "where p.aktyvi='Y' and p.tip=0  and trim(k.rkod)=? and (d.DATA_PAKR between ? and ? or o.status<200)"
   con = kinterbasdb.connect(dsn='firebird-pc.latgrupe.eu:Luckust', user='sysdba', password='masterkey', charset='UTF8')
   cur = con.cursor()
   cur.execute("""select distinct d.eilnr,d.DATA_PAKR, p.KOD || ' ' || c.pavad item,o.kiekis0,
      coalesce(o.kiekis1+o.kiekis2+o.kiekis3+o.kiekis4,0) rez,
      o.status pdata,o.KAINA,o.kaina*o.KIEKIS0 suma,iif(o.STATUS<1,'Open',iif(o.status=200,'Invoiced/Completed','Execute')) status,k.pavad,o.id_trmapv,o.id_trmprk,d.id_trmdok
      ,o.kiekis1,iif(kiekis1>0,cast(cast('now' as date) as varchar(10)),'-') dt1  
      ,o.kiekis2,iif(kiekis2>0,iif(cast(cast('now' as date) as varchar(10))>cast(cast(o.modify_date as date)+5 as varchar(10)) ,cast(cast('now' as date) as varchar(10)),cast(cast(o.modify_date as date)+5 as varchar(10))),'-') dt2
      ,o.kiekis3,iif(kiekis3>0,iif(cast(cast('now' as date) as varchar(10))>cast(cast(o.modify_date as date)+7 as varchar(10)),cast(cast('now' as date) as varchar(10)),cast(cast(o.modify_date as date)+7 as varchar(10))),'-') dt3
      ,o.kiekis4,iif(kiekis4>0,cast((select first 1 cast(d1.data_pakr+60 as date) from trmapv a1 left join trmdok d1 on a1.id_trmdok=d1.id_trmdok where a1.ID_TRMPRK=o.id_trmprk and a1.kiekis=0 and a1.OPTIP=2 
      and d1.sutvarkyta='N' and d1.data_iskr is null) as varchar(10)),'-') dt4, o.vartot 
      ,k.id_trmkl,trim(r.kod),trim(r.adr),trim(r.pindex),trim(r.salis),o.pkiekis
      from trmdok d left join trmorder o on d.id_trmdok=o.id_trmdok left join trmprk p on p.id_trmprk=o.id_trmprk 
      left join trmdict c on p.id_txt6=c.id_trmdict left join trmkl k on k.ID_trmKL=d.ID_KL left join trmkladr r on o.id_kladr=r.id_trmadr            
      """+tx+""" order by o.id_trmapv""",[imone,nuo,iki])
   result_list = []
   viso_suma = 0
   for row in cur.fetchall():
      viso_suma =  viso_suma+row[7]
      p = {'nr': row[0], 'data': row[1], 'item': row[2], 'kiekis': row[3], 'rez': row[4], 'pdata': row[5], 'kaina': row[6], 'suma': row[7], 'status': row[8], 'klpavad':row[9], 'idapv':row[10], 'idprk':row[11],
           'iddok':row[12], 'kiekis1':row[13], 'dt1':row[14], 'kiekis2':row[15], 'dt2':row[16], 'kiekis3':row[17], 'dt3':row[18], 'kiekis4':row[19], 'dt4':row[20], 'vartot':row[21]
          , 'id_trmkl': row[22], 'adrkod': row[23], 'adr': row[24], 'index': row[25], 'salis': row[26], 'pkiekis':row[27]}
      result_list.append(p)

   return render(request, 'orders.html', {'result_list': result_list, 'viso_suma': viso_suma,'nuo': nuo, 'iki': iki})
 else:
     return render(request, 'index.html')

def export_orders_xls(request):
   if request.user.groups.filter(name='Terminal').exists():
    response = HttpResponse(content_type='application/ms-excel')
    imone = request.user.first_name
    filename=request.user.username+'_orders.xls'
    response['Content-Disposition'] = 'attachment; filename=%s'%filename
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('Luminaires')
    if request.user.first_name == 'admin':
        tx = "where p.aktyvi='Y' and p.tip=?"
        imone = 0
    else:
        tx = "where p.aktyvi='Y' and p.tip=0  and trim(k.rkod)=?"

    # Sheet header, first row
    row_num = 0

    font_style = xlwt.XFStyle()
    font_style.font.bold = True
    columns = ['Order No', 'Date','Item', 'Order Qty', 'Invoiced Qty', 'Delivery now','Delivery 1-5 workdays','Delivery 5-10 workdays', 'On the way', 'Status', 'User']

    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], font_style)

    # Sheet body, remaining rows
    font_style = xlwt.XFStyle()
    con = kinterbasdb.connect(dsn='firebird-pc.latgrupe.eu:Luckust', user='sysdba', password='masterkey', charset='UTF8')
    cur = con.cursor()

    cur.execute("""select distinct d.eilnr,cast(cast(d.DATA_PAKR as date) as varchar(10)), p.KOD || ' ' || c.pavad item,o.kiekis0,o.pkiekis,
      o.kiekis1,o.kiekis2,o.kiekis3,o.kiekis4,iif(o.STATUS<1,'Open',iif(o.status=200,'Invoiced/Completed','Execute')),o.vartot 
      from trmdok d left join trmorder o on d.id_trmdok=o.id_trmdok left join trmprk p on p.id_trmprk=o.id_trmprk 
      left join trmdict c on p.id_txt6=c.id_trmdict left join trmkl k on k.ID_trmKL=d.ID_KL           
      """+tx+""" """,[imone])
    for row in cur.fetchall():
         row_num += 1
         for col_num in range(len(row)):
             ws.write(row_num, col_num, row[col_num], font_style)

    wb.save(response)
    return response
   else:
       return render(request, 'index.html')

def cart_items(request,idadr=-2):
 if request.user.groups.filter(name='Terminal').exists():
   imone = request.user.first_name
   vartot = request.user.username
   vardas = request.user.last_name
   dt = str(date.today())
   kod = ''
   con = kinterbasdb.connect(dsn='firebird-pc.latgrupe.eu:Luckust', user='sysdba', password='masterkey', charset='UTF8')
   cur = con.cursor()

   if 'del' in request.POST and request.POST['uzskiekis'] == '' and request.POST['uzskaina'] != '':
       id = int(request.POST['id'])
       cur.execute("""delete from trmcart where id_trmcart=? """, [id])
       con.commit()
   else:
       if 'info' in request.POST:
           id = int(request.POST['id'])
           info = request.POST['info']
           cur.execute("""update trmcart set vartot=?, info=? where id_trmcart=? """, [vartot, info, id])
           con.commit()
       else:
           if 'idadr' in request.POST:
               idadr = int(request.POST['idadr'])
               id = int(request.POST['id'])
               cur.execute("""update trmcart set id_kladr=?, vartot=? where id_trmcart=? """, [idadr, vartot, id])
               con.commit()
           else:
               if 'uzskiekis' in request.POST:
                   id = int(request.POST['id'])
                   kiek = float(request.POST['uzskiekis'])
                   cur.execute("""update trmcart set kiekis=?, suma=kaina*?  where id_trmcart=? """, [kiek, kiek, id])
                   con.commit()

     # if request.method == 'POST' and request.POST['uzskiekis'] == '' and request.POST['uzskaina'] == '':
       #     count = 0
       #     cur.execute("""select kod from trmkl where trim(rkod)=?""", [imone])
       #     for row in cur:
       #         count = 1
       #     if count == 0:
       #         cur.execute(
       #             """insert into trmkl (ID_trmkl, kod, pavad, rkod) VALUES (GEN_ID(id_kl_gen,1), ?,?, ?) """,
       #             [vardas, vartot, imone])
       #         cur.execute(
       #             """insert into trmkladr (ID_trmkl, kod, adr, vartot) VALUES (GEN_ID(id_kl_gen,0), ?,'Address',?) """,
       #             [vardas, vartot])
       #         con.commit()
       #     count = 0
       #     cur.execute("""select count(id_trmcart) from trmcart where customer=?""", [imone])
       #     for row in cur:
       #         count = 1
       #
       #     if request.user.groups.filter(name='Branch').exists():
       #         tx = ' and vartot=?'
       #     else:
       #         tx = ' and memo<>?'
       #
       #     if count != 0:
       #         cur.execute("""insert into trmdok (ID_TRMDOK,data_pakr,id_kl,doktip,eilnr,kiekis,DOK_USER) select GEN_ID(id_dok_gen,1) id_trmdok,? ,
       #        coalesce((select first 1 id_trmkl from trmkl where trim(RKOD)=?),-1) id_kl,5 doktip,GEN_ID(id_dok_gen,0) eilnr,coalesce(sum(kiekis),0) kiekis,?
       #         from trmcart where CUSTOMER=? """, [dt, imone, vartot, imone, imone])
       #         cur.execute("""insert into trmorder (ID_TRMDOK,id_trmprk,KAINA,KIEKIS,KIEKIS0,OPTIP,VARTOT,id_kladr) select GEN_ID(id_dok_gen,0) id_trmdok,
       #        (select first 1 id_trmprk from trmprk where kod=trmcart.kod),kaina,kiekis,kiekis,5,?,trmcart.id_kladr
       #        from trmcart where CUSTOMER=?"""+tx+""" """, [vartot, imone,vartot])
       #         cur.execute("""delete from trmcart where CUSTOMER=? """+tx+"""""", [imone,vartot])
       #         con.commit()

   if request.user.groups.filter(name='Branch').exists():
       htm = 'cart_branch.html'
       tx = ' where id_trmkl=(select first 1 id_trmkl from trmkl where rkod=?) and vartot=?'
       tx2 = ' and t.vartot=?'
   else:
       htm = 'cart.html'
       tx = ' where id_trmkl=(select first 1 id_trmkl from trmkl where rkod=?) and salis<>?'
       tx2 = ' and t.kod<>?'

   cur.execute("""select distinct p.KOD,c.pavad,t.KAINA,t.KIEKIS,P.BRUTTO*t.kiekis svoris,t.suma,t.id_trmcart,t.vartot,t.id_kladr,t.info    
     from TRMPRK P left join trmdict c on p.id_txt6=c.id_trmdict left join trmcart t on p.kod=t.kod      
     where p.aktyvi='Y' and p.tip=0 and t.customer=? """+tx2+"""  order by t.id_trmcart """, [imone, vartot])
   result_list = []
   viso_suma = 0
   for row in cur.fetchall():
      p = {'kod': row[0], 'pavad': row[1], 'kaina': row[2], 'kiekis': row[3], 'svoris': row[4], 'suma': row[5], 'id': row[6],'vartot':row[7],'id_kladr':row[8],'info':row[9]}
      if request.user.groups.filter(name='Branch').exists():
          viso_suma = viso_suma + row[3]
      else:
          viso_suma = viso_suma+ row[5]

      result_list.append(p)

   cur.execute("""select id_trmadr,kod || ' ' || adr || ' ' || pindex || ' ' || salis from trmkladr  """+tx+""" order by id_trmadr""",[imone,vartot])
   adr_list = []

   for row in cur.fetchall():
      p = {'id_kladr': row[0], 'address': row[1]}
      adr_list.append(p)

   return render(request, htm, {'result_list': result_list, 'viso_suma': viso_suma, 'adr_list': adr_list, 'idadr':idadr})
 else:
     return render(request, 'index.html')

def order_confirm(request):
 if request.user.groups.filter(name='Terminal').exists():
   imone = request.user.first_name
   vartot = request.user.username
   vardas = request.user.last_name
   dt = str(date.today())

   con = kinterbasdb.connect(dsn='firebird-pc.latgrupe.eu:Luckust', user='sysdba', password='masterkey', charset='UTF8')
   cur = con.cursor()
   if request.method == 'POST' and request.POST['uzskiekis'] == '' and request.POST['uzskaina'] == '' and request.POST['id'] != '-1':
       count = 0
       cur.execute("""select kod from trmkl where trim(rkod)=?""", [imone])
       for row in cur:
           count = 1
       if count == 0:
           cur.execute(
               """insert into trmkl (ID_trmkl, kod, pavad, rkod) VALUES (GEN_ID(id_kl_gen,1), ?,?,?) """,
               [vartot, vardas,  imone])

           cur.execute(
               """insert into trmkladr (ID_trmkl, kod, adr, vartot) VALUES (GEN_ID(id_kl_gen,0), ?,'Address',?) """,
               [vardas, vartot])
           con.commit()
       count = 0
       cur.execute("""select count(id_trmcart) from trmcart where customer=?""", [imone])
       for row in cur:
           count = 1

       if request.user.groups.filter(name='Branch').exists():
           tx = ' and vartot=?'
       else:
           tx = ' and memo<>?'

       if count != 0:
           cur.execute("""insert into trmdok (ID_TRMDOK,data_pakr,id_kl,doktip,eilnr,kiekis,DOK_USER) select GEN_ID(id_dok_gen,1) id_trmdok,? ,
          coalesce((select first 1 id_trmkl from trmkl where trim(RKOD)=?),-1) id_kl,5 doktip,GEN_ID(id_dok_gen,0) eilnr,coalesce(sum(kiekis),0) kiekis,?
           from trmcart where CUSTOMER=? """, [dt, imone, vartot, imone, imone])
           cur.execute("""insert into trmorder (ID_TRMDOK,id_trmprk,KAINA,KIEKIS,KIEKIS0,OPTIP,VARTOT,id_kladr,info) select GEN_ID(id_dok_gen,0) id_trmdok,
          (select first 1 id_trmprk from trmprk where kod=trmcart.kod),kaina,kiekis,kiekis,5,?,trmcart.id_kladr,info 
          from trmcart where CUSTOMER=?""" + tx + """ """, [vartot, imone, vartot])
           cur.execute("""delete from trmcart where CUSTOMER=? """ + tx + """""", [imone, vartot])
           con.commit()

   if request.user.groups.filter(name='Branch').exists():
       htm = 'order_confirm.html'
       tx2 = ' and t.vartot=?'
   else:
       htm = 'order_confirm.html'
       tx2 = ' and t.memo<>?'


   cur.execute("""select distinct p.KOD,c.pavad,t.KAINA,t.KIEKIS,P.BRUTTO*t.kiekis svoris,t.suma,t.id_trmcart,t.vartot,t.id_kladr,k.pavad, r.adr,r.pindex,r.salis,t.info   
     from TRMPRK P left join trmdict c on p.id_txt6=c.id_trmdict left join trmcart t on p.kod=t.kod left join trmkl k on t.customer=k.rkod 
     left join trmkladr r on r.id_trmkl=k.id_trmkl and t.ID_KLADR=r.ID_TRMADR    
     where p.aktyvi='Y' and p.tip=0 and t.customer=? """+tx2+"""  order by t.id_trmcart """, [imone, vartot])
   result_list = []
   viso_suma = 0
   for row in cur.fetchall():
      p = {'kod': row[0], 'pavad': row[1], 'kaina': row[2], 'kiekis': row[3], 'svoris': row[4], 'suma': row[5], 'id': row[6],'vartot':row[7],'id_kladr':row[8]
          , 'klpavad': row[9],'adr':row[10],'index':row[11],'salis':row[12],'info':row[13]}
      if request.user.groups.filter(name='Branch').exists():
          viso_suma = viso_suma + row[3]
      else:
          viso_suma = viso_suma+ row[5]
      result_list.append(p)

   return render(request, htm, {'result_list': result_list, 'viso_suma': viso_suma})
 else:
     return render(request, 'index.html')


def export_cart_xls(request):
   if request.user.groups.filter(name='Terminal').exists():
    response = HttpResponse(content_type='application/ms-excel')
    imone = request.user.first_name
    filename=request.user.username+'_cart.xls'
    response['Content-Disposition'] = 'attachment; filename=%s'%filename
    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('Luminaires')

    # Sheet header, first row
    row_num = 0

    font_style = xlwt.XFStyle()
    font_style.font.bold = True

    if request.user.groups.filter(name='Branch').exists():
        columns = ['Item', 'Description','Weight','Quantity', 'Delivery now','Delivery 1-5 workdays','Delivery 5-10 workdays']
        tx = ''
    else:
        columns = ['Item', 'Description','Weight','Price', 'Amount','Quantity','Delivery now','Delivery 1-5 workdays','Delivery 5-10 workdays']
        tx = 'price_partner,suma,'

    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], font_style)

    # Sheet body, remaining rows
    font_style = xlwt.XFStyle()
    con = kinterbasdb.connect(dsn='firebird-pc.latgrupe.eu:Luckust', user='sysdba', password='masterkey', charset='UTF8')
    cur = con.cursor()

    cur.execute("""select kod,pavad,svoris,"""+tx+"""uzskiekis,iif(uzskiekis>kiekis_cl,kiekis_cl,uzskiekis) dabar,
     iif(iif(lik<=s,lik,s)<0,0,iif(lik<=s,lik,s)) iki3,
     iif(iif(lik-s<=r,lik-s,r)<0,0,iif(lik-s<=r,lik-s,r)) iki5
     from(
     select p.KOD,c.pavad,c2.pavad as gamintojas, sum(t.kiekis)/count(p.kod) uzskiekis, sum(p.kiekis_1)/count(p.kod) kiekis_cl,(sum(t.kiekis)/count(p.kod))-(sum(p.kiekis_1)/count(p.kod)) lik,sum(P.BRUTTO*t.kiekis)/count(p.kod) svoris,sum(t.suma)/count(p.kod) suma,
     sum(coalesce((select sum(a1.likutis-a1.rezervuota) from trmapv a1 where a1.ID_TRMPRK=P.ID_TRMPRK and a1.optip=2),0)) as kiekis,
     sum(coalesce((select sum(a1.likutis-a1.rezervuota) from trmapv a1 where a1.ID_TRMPRK=P.ID_TRMPRK and a1.optip=2 and char_length(a1.muitkod_rf)>8),0)) as s,
     sum(coalesce((select sum(a1.likutis-a1.rezervuota) from trmapv a1 where a1.ID_TRMPRK=P.ID_TRMPRK and a1.optip=2 and char_length(a1.muitkod_rf)<=8),0)) as r,
     sum(coalesce((select sum(a1.kiekis0) from trmapv a1 left join trmdok d1 on a1.id_trmdok=d1.id_trmdok where a1.ID_TRMPRK=P.ID_TRMPRK and a1.kiekis=0 and a1.OPTIP=2 and d1.sutvarkyta='N' and d1.data_iskr is null),0)) as atvyksta
     ,p.price_ukr,p.price_partner,p.price_public,
     min((select first 1 cast(cast(d1.data_pakr+60 as date) as varchar(10)) from trmapv a1 left join trmdok d1 on a1.id_trmdok=d1.id_trmdok where a1.ID_TRMPRK=P.ID_TRMPRK and a1.kiekis=0 and a1.OPTIP=2 and d1.sutvarkyta='N' and d1.data_iskr is null)) as datatvyksta
     from TRMPRK P left join trmdict c on p.id_txt6=c.id_trmdict left join trmdict c2 on  p.id_gam=c2.id_trmdict left join trmcart t on p.kod=t.kod 
     where p.aktyvi='Y' and p.tip=0 and t.CUSTOMER=?
     group by  p.kod,c.pavad,c2.pavad,p.muitkod,p.price_ukr,p.price_partner,p.price_public    
     )""",[imone])
    for row in cur.fetchall():
         row_num += 1
         for col_num in range(len(row)):
             ws.write(row_num, col_num, row[col_num], font_style)

    wb.save(response)
    return response
   else:
       return render(request, 'index.html')


def export_trmprk_xls(request):
   if request.user.groups.filter(name='Terminal').exists():
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename="luminaires.xls"'

    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('Luminaires')

    # Sheet header, first row
    row_num = 0

    font_style = xlwt.XFStyle()
    font_style.font.bold = True
    tx = ''
    if request.user.groups.filter(name='Branch').exists():
        columns = ['Item', 'Product description', 'Quantity', 'Delivery 1-5 workdays', 'Delivery 5-10 workdays',
                   'On the way (call)', 'Date of arrival' ]
        tx = ''
    else:
        columns = ['Item', 'Product description', 'Quantity', 'Delivery 1-5 workdays', 'Delivery 5-10 workdays',
                   'On the way (call)', 'Date of arrival', 'Price partner', 'Price public', ]
        tx = ',p.price_partner,p.price_public'


    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], font_style)

    # Sheet body, remaining rows
    font_style = xlwt.XFStyle()
    con = kinterbasdb.connect(dsn='firebird-pc.latgrupe.eu:Luckust', user='sysdba', password='masterkey', charset='UTF8')
    cur = con.cursor()

    cur.execute("""select p.KOD,c.pavad, sum(p.kiekis_1)/count(p.kod) kiekis_cl,

      sum(coalesce((select sum(a1.likutis-a1.rezervuota) from trmapv a1 where a1.ID_TRMPRK=P.ID_TRMPRK and a1.optip=2 and char_length(a1.muitkod_rf)>8),0)) as s,
      sum(coalesce((select sum(a1.likutis-a1.rezervuota) from trmapv a1 where a1.ID_TRMPRK=P.ID_TRMPRK and a1.optip=2 and char_length(a1.muitkod_rf)<=8),0)) as r,
      sum(coalesce((select sum(a1.kiekis0) from trmapv a1 left join trmdok d1 on a1.id_trmdok=d1.id_trmdok where a1.ID_TRMPRK=P.ID_TRMPRK and a1.kiekis=0 and a1.OPTIP=2 and d1.sutvarkyta='N'),0)) as atvyksta,
      cast(cast(min((select first 1 d1.data_pakr+60  from trmapv a1 left join trmdok d1 on a1.id_trmdok=d1.id_trmdok where a1.ID_TRMPRK=P.ID_TRMPRK and a1.kiekis=0 and a1.OPTIP=2 and d1.sutvarkyta='N' and d1.data_iskr is null)) as date) as varchar(10)) as datatvyksta
      """+tx+"""
      from TRMPRK P left join trmdict c on p.id_txt6=c.id_trmdict left join trmdict c2 on  p.id_gam=c2.id_trmdict 
      where p.aktyvi='Y' and p.tip=0 and ((p.kiekis>0) or (p.kiekis_1>0))
      group by  p.kod,c.pavad,c2.pavad,p.muitkod"""+tx+"""
      order by p.kod""")
    for row in cur.fetchall():
         row_num += 1
         for col_num in range(len(row)):
             ws.write(row_num, col_num, row[col_num], font_style)

    wb.save(response)
    return response
   else:
       return render(request, 'index.html')

def clop_list(request,dt1=None,dt2=None,imone=None):
  if request.user.groups.filter(name='Branch').exists():
      today = date.today()
  elif request.user.groups.filter(name='Terminal').exists():
    if dt1 is None:
        today = date.today()
        first = date(day=1, month=today.month, year=today.year)
        dt1 = str(first)
        dt2 = str(date.today())
    kwargs = {}
    kwargs['data__range'] = ("%s-%s-%s" % (dt1[0:4], dt1[5:7], dt1[8:10]),
                             "%s-%s-%s" % (dt2[0:4], dt2[5:7], dt2[8:10]))

    context = {
        "nuo": dt1[:10],
        "iki": dt2[:10],
    }
    if request.user.first_name != 'admin':
        imone = request.user.first_name
        tx = ' and trim(k.rkod) ='+imone
    if imone is None:
        tx = ''
    if 'nuo' and 'iki' in request.GET:
        dt1 = request.GET['nuo']
        dt2 = request.GET['iki']

    con2 = kinterbasdb.connect(dsn='firebird-pc.latgrupe.eu:ClaraLux', user='sysdba', password='masterkey', charset='WIN1257')
    cur = con2.cursor()

    cur.execute("""select d.id_dok,d.data,trim(d.doknr) doknr,trim(k.pavad) klpavad,d.val,d.savik,d.pvm,d.skola,d.apmsum
                   from dok d left join kl k on d.id_kl=k.id_kl 
                   where d.doktip=4 and d.data between ? and ?  """+tx+""" order by 2 asc""",[dt1,dt2])

    result_list = []
    for row in cur.fetchall():
        p = {'id': row[0], 'datad': row[1], 'doknr': row[2], 'klpavad': row[3], 'dokval':row[4],'doksavik':row[5],'dokpvm':row[6],'dokskola':row[7],'dokapm':row[8]}
        # p.num_responses = row[2]
        result_list.append(p)
    return render(request, 'clop.html', {'result_list': result_list,'nuo':dt1,'iki':dt2})
  else:
      return render(request, 'index.html')

def clop_detail(request,iddok=None):
  if request.user.groups.filter(name='Branch').exists():
     iddok = -1
  elif request.user.groups.filter(name='Terminal').exists():
    if iddok is None:
        id=-1


    if iddok in request.GET:
        id = request.GET['iddok']
    con2 = kinterbasdb.connect(dsn='firebird-pc.latgrupe.eu:ClaraLux', user='sysdba', password='masterkey', charset='WIN1257')
    cur = con2.cursor()


    cur.execute("""select d.id_dok,a.data,trim(d.doknr) doknr,trim(k.pavad) klpavad,trim(p.kod) prkkod,trim(p.pavad1) prkpavad, abs(a.kiekis) kiekis,a.savik,a.parkn,a.pvm,(abs(a.kiekis)*a.parkn)+a.pvm suma
                   from APV a left join dok d on a.id_dok=d.id_dok left join kl k on a.id_kl=k.id_kl left join prk p on a.id_prk=p.id_prk and a.id_snd=p.id_snd
                   left join snd s on a.id_snd=s.id_Snd
                   where a.rectip='Y' and (a.optip=4 or a.optip=13) and d.id_dok= ? order by 2 asc""",[iddok])

    result_list = []
    for row in cur.fetchall():
        p = {'id': row[0], 'datad': row[1], 'doknr': row[2], 'klpavad': row[3], 'prkkod': row[4], 'prkpavad': row[5], 'kiekis': row[6], 'savik': row[7], 'parkn': row[8], 'pvm': row[9], 'suma': row[10]}
        doknr = row[2]
        klkod = row[3]
        result_list.append(p)
    return render(request, 'clop_detail.html', {'result_list': result_list, 'doknr':doknr,'klkod':klkod})
  else:
      return render(request, 'index.html')

def export_clop_xls(request,nuo,iki,imone=None):
   if request.user.groups.filter(name='Branch').exists():
       imone = ''
   elif request.user.groups.filter(name='Terminal').exists():
    response = HttpResponse(content_type='application/ms-excel')
    filename='Invoices.xls'
    response['Content-Disposition'] = 'attachment; filename=%s'%filename

    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('Invoices')

    # Sheet header, first row
    row_num = 0
    if request.user.first_name != 'admin':
        imone = request.user.first_name
        tx = ' and trim(k.rkod) ='+imone
    if imone is None:
        tx = ''

    font_style = xlwt.XFStyle()
    font_style.font.bold = True

    columns = ['Date', 'Doc.No.',  'Customer', 'Currency', 'VAT', 'Amount', 'Paid',]

    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], font_style)

    # Sheet body, remaining rows
    font_style = xlwt.XFStyle()
    con2 = kinterbasdb.connect(dsn='firebird-pc.latgrupe.eu:ClaraLux', user='sysdba', password='masterkey', charset='WIN1257')
    cur = con2.cursor()

    cur.execute("""select cast(cast(d.data as date) as varchar(10)),trim(d.doknr) doknr,trim(k.pavad) klpavad,d.val,d.pvm,d.skola,d.apmsum
                       from dok d left join kl k on d.id_kl=k.id_kl 
                       where d.doktip=4 and d.data between ? and ?  """+tx+""" order by 2 asc""", [nuo, iki])
    for row in cur.fetchall():
         row_num += 1
         for col_num in range(len(row)):
             ws.write(row_num, col_num, row[col_num], font_style)

    wb.save(response)
    return response
   else:
       return render(request, 'index.html')

def export_clop_detail_xls(request,nuo,iki,imone=None):
   if request.user.groups.filter(name='Branch').exists():
       imone = ''
   elif request.user.groups.filter(name='Terminal').exists():
    response = HttpResponse(content_type='application/ms-excel')
    filename ='Invoices_detail.xls'
    response['Content-Disposition'] = 'attachment; filename=%s'%filename

    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('Invoices')

    # Sheet header, first row
    row_num = 0
    if request.user.first_name != 'admin':
        imone = request.user.first_name
        tx = ' and trim(k.rkod) ='+imone
    if imone is None:
        tx = ''

    font_style = xlwt.XFStyle()
    font_style.font.bold = True

    columns = ['Date', 'Doc.No.',  'Customer', 'Code', 'Product description', 'Quantity', 'Price', 'VAT', 'Amount',]

    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], font_style)

    # Sheet body, remaining rows
    font_style = xlwt.XFStyle()
    con2 = kinterbasdb.connect(dsn='firebird-pc.latgrupe.eu:ClaraLux', user='sysdba', password='masterkey', charset='WIN1257')
    cur = con2.cursor()

    cur.execute("""select cast(cast(d.data as date) as varchar(10)),trim(d.doknr) doknr,trim(k.pavad) klpavad,trim(p.kod) prkkod,trim(p.pavad1) prkpavad, abs(a.kiekis) kiekis,a.parkn,a.pvm,(abs(a.kiekis)*a.parkn)+a.pvm suma 
                   from APV a left join dok d on a.id_dok=d.id_dok left join kl k on a.id_kl=k.id_kl left join prk p on a.id_prk=p.id_prk and a.id_snd=p.id_snd
                   left join snd s on a.id_snd=s.id_Snd
                   where a.rectip='Y' and (a.optip=4 or a.optip=13) and (substring(p.pozymiai from 1 for 1) = '1') and a.data between ? and ?  """+tx+""" """,[nuo,iki])
    for row in cur.fetchall():
         row_num += 1
         for col_num in range(len(row)):
             ws.write(row_num, col_num, row[col_num], font_style)

    wb.save(response)
    return response
   else:
       return render(request, 'index.html')

def clprk_list(request,dt1=None,dt2=None):
 if request.user.groups.filter(name='ClaraLux').exists():
    if dt1 is None:
        today = date.today()
        first = date(day=1, month=today.month, year=today.year)
        dt1 = str(first)
    dt2 = str(datetime.now())
    kwargs = {}
    kwargs['data__range'] = ("%s-%s-%s" % (dt1[0:4], dt1[5:7], dt1[8:10]),
                             "%s-%s-%s" % (dt2[0:4], dt2[5:7], dt2[8:10]))

    context = {
        "nuo": dt1[:10],
        "iki": dt2[:10],
    }
    con2 = kinterbasdb.connect(dsn='firebird-pc.latgrupe.eu:ClaraLux', user='sysdba', password='masterkey', charset='WIN1257')
    cur = con2.cursor()

    cur.execute("""select  id_prk_rec,id_prk,kod,pavad1,sum(kiekis) kiekis from prk where class=0 and id_snd=1345 and (substring(pozymiai from 1 for 1) = '1') group by kod,pavad1,id_prk_rec,id_prk  """)

    result_list = []
    for row in cur.fetchall():
        p = {'idrec': row[0],'idprk': row[1],'kod': row[2],'pavad': row[3],'kiekis': row[4]}
        # p.num_responses = row[2]
        result_list.append(p)
    return render(request, 'clprk.html', {'result_list': result_list})
 else:
     return render(request, 'index.html' )

def export_clprk_xls(request):
   if request.user.groups.filter(name='ClaraLux').exists():
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename="CLItems.xls"'

    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('ClaraLux')

    # Sheet header, first row
    row_num = 0

    font_style = xlwt.XFStyle()
    font_style.font.bold = True

    columns = ['Code', 'Product description', 'Quantity']

    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], font_style)

    # Sheet body, remaining rows
    font_style = xlwt.XFStyle()
    con2 = kinterbasdb.connect(dsn='firebird-pc.latgrupe.eu:ClaraLux', user='sysdba', password='masterkey', charset='WIN1257')
    cur = con2.cursor()

    cur.execute("""select kod,pavad1,sum(kiekis) kiekis from prk where class=0 and id_snd=1345 and (substring(pozymiai from 1 for 1) = '1') group by kod,pavad1""")
    for row in cur.fetchall():
         row_num += 1
         for col_num in range(len(row)):
             ws.write(row_num, col_num, row[col_num], font_style)

    wb.save(response)
    return response
   else:
       return render(request, 'index.html')



def check_orders(request):
 if request.user.groups.filter(name='Admins').exists():
    vartot = request.user.username
    idapv = -1
    iddok = -1
    idprk = -1
    kiekis0 = 0
    con = kinterbasdb.connect(dsn='firebird-pc.latgrupe.eu:Luckust', user='sysdba', password='masterkey', charset='UTF8')
    cur = con.cursor()
    cur.execute("""select id_trmapv,id_trmdok,id_trmprk,kiekis0 from trmorder where status<200 order by id_trmapv """)
    for row in cur.fetchall():
        idapv = row[0]
        iddok = row[1]
        idprk = row[2]
        kiekis0 = row[3]
        reserve(idapv, iddok, idprk, kiekis0,vartot)
    return render(request, 'index.html')
 else:
    return render(request, 'index.html')




def reserve(idapv,iddok,idprk,rezkiekis,vartot):

    dt2 = str(date.today())

    con = kinterbasdb.connect(dsn='firebird-pc.latgrupe.eu:Luckust', user='sysdba', password='masterkey', charset='UTF8')
    cur = con.cursor()
    con2 = kinterbasdb.connect(dsn='firebird-pc.latgrupe.eu:ClaraLux', user='sysdba', password='masterkey', charset='WIN1257')
    cur2 = con2.cursor()
    cur.execute(
        """select first 1 trim(k.rkod),trim(k.pavad),d.eilnr from trmkl k left join trmdok d on k.id_trmkl=d.id_kl where d.id_trmdok=? """,
        [iddok])
    for row in cur.fetchall():
        rkod = row[0]
        klpavad = row[1]
        doknr = row[2]
    cur.execute("""select first 1 trim(p.kod),trim(c.pavad),p.price_partner from TRMPRK P left join trmdict c on p.id_txt6=c.id_trmdict  where p.id_trmprk=? """, [idprk])
    kodas = ''
    prkpavad = ''
    prkprice = 0
    for row in cur.fetchall():
        kodas = row[0]
        prkpavad = kodas + ' ' + row[1]
        prkprice = row[2]

    cur.execute("""delete from trmapv where id_trmapvo=? and id_trmdok=? """, [idapv, iddok])
    cur2.execute(
        """delete from prk_rez where id_prk=(select first 1 id_prk from prk where trim(kod)=?) and id_sdok=(select first 1 id_sdok from sdok where trim(doknr)=?) """,
        [kodas, doknr])
    cur2.execute(
        """delete from spub2 where id_prk=(select first 1 id_prk from prk where trim(kod)=?) and id_sdok=(select first 1 id_sdok from sdok where trim(doknr)=?) """,
        [kodas, doknr])
    cur2.execute(
        """select id_sdok from spub2 where id_sdok=(select first 1 id_sdok from sdok where trim(doknr)=?) """,
        [doknr])
    yra = 0
    kiekis0 = 0

    for row2 in cur2.fetchall():
        yra = 1
    if yra == 0:
        cur2.execute("""delete from sdok where trim(doknr)=? """, [doknr])

    cur.execute("""update trmorder set pkiekis=0,kiekis1=0,kiekis2=0,kiekis3=0,kiekis4=0,status=0 where id_trmapv=? """, [idapv])

    cur2.execute("""select coalesce(sum(abs(kiekis)),0) from apv where rectip='Y' and id_dok=(select first 1 id_dok from dok where trim(doknr)=? or POSITION(?,trim(doknr2))>0)
             and id_prk=(select first 1 id_prk from prk where trim(kod)=?) """, [doknr, doknr, kodas])
    kiek = 0
    for row2 in cur2.fetchall():
        kiek = row2[0]
    if kiek !=0:
        cur.execute("""update trmorder set pkiekis=?,kiekis1=0,kiekis2=0,kiekis3=0,kiekis4=0,status=200 where id_trmapv=? """,
                        [kiek,idapv])
        rezkiekis = 0

    kiekis0 = rezkiekis

    if rezkiekis > 0:
        id_prk = -1
        yra = 0
        cur2.execute("""select first 1 id_prk from prk where trim(kod)=? """, [kodas])
        for row2 in cur2.fetchall():
            yra = 1
            id_prk = row2[0]
        if yra == 0:
            cur2.execute(
                """insert into prk (id_prk_rec,id_prk,kod,pavad,pavad1,kn2,kn2_type,id_snd,vnt) values (GEN_ID(id_prk_rec_gen,1),GEN_ID(id_prk_gen,1),?,?,?,?,'Y',1345,'vnt.')""",
                [kodas,kodas, prkpavad, prkprice])
        yra = 0
        cur2.execute("""select first 1 id_kl from kl where trim(rkod)=? """, [rkod])
        for row2 in cur2.fetchall():
            yra = 1
        if yra == 0:
            cur2.execute("""insert into kl (id_kl,rkod,kod,pavad) values (GEN_ID(id_kl_gen,1),?,?,?)""",
                         [rkod, rkod, klpavad])



        kiekis0 = rezkiekis

        if rezkiekis > 0:
            suma = 0
            kaina = prkprice
            cur2.execute("""select first 1 p.kn2 from prk p where trim(p.kod)=? and p.id_snd=1345 """, [kodas])
            for row2 in cur2.fetchall():
                suma = kiekis0 * row2[0]
                kaina = row2[0]

            adresas = ''
            inf = ''
            cur.execute(
                """select trim(r.adr || ' '|| r.pindex || ' '||r.salis),o.info   from TRMKLADR r inner join trmorder o on r.ID_TRMadr=o.id_kladr where ID_TRMapv=? """, [idapv])
            for row in cur.fetchall():
                adresas = row[0]
                inf= row[1]

            yra = 0
            cur2.execute("""select first 1 id_sdok from sdok where doknr=? or doknr2=?""", [doknr,doknr])
            for row2 in cur2.fetchall():
                yra = 1
            if yra == 0:
                cur2.execute(
                    """insert into sdok (id_sdok,data,doknr,doknr2,doktip,id_kl,id_snd,suma,sumviso,pvm,kurs,val,sumnuol,skola,sdok_user,ch1,pr_vieta,kieno_tr,kntip,apm_sal,id_bank,sf_tip) values (GEN_ID(id_dok_gen,1),?,?,?,4,coalesce((select first 1 id_kl from kl where trim(rkod)=?),-1),1345,?,?,?,1,'EUR',?,?,?,'Y',?,1,4,1,1,'SF')""",
                    [dt2, doknr,doknr, rkod, suma, suma, suma * 1.21 - suma, suma * 1.21, suma * 1.21, vartot,adresas])
                cur2.execute("""insert into spub2 (id_rec,id_sdok,id_prk,id_snd,kiekis,parkn,pvmproc,pvm,vnt,uzs_prkkod,comment,pvm_kod) values (GEN_ID(id_apv_gen,1),GEN_ID(id_dok_gen,0),coalesce((select first 1 id_prk from prk where trim(kod)=? ),-1),
                                 1345,?,?,21,?,'vnt.',?,?,'PVM1')""", [kodas, kiekis0, kaina, suma * 1.21 - suma, kodas,inf])
                cur2.execute("""insert into prk_rez (id,id_dok,id_sdok,id_prk,id_snd,kiekis,rez_type,author,terminas) values (GEN_ID(id_snd_gen,1),-1,GEN_ID(id_dok_gen,0),coalesce((select first 1 id_prk from prk where trim(kod)=? ),-1),
                                           1345,?,4,?,?+10)""", [kodas, kiekis0, vartot, dt2])
            else:
                yra = 0
                cur2.execute("""select first 1 id_sdok from spub2 where id_sdok=(select first 1 id_sdok from sdok where doknr=? or doknr2=?) and id_prk=?""", [doknr,doknr, id_prk])
                for row2 in cur2.fetchall():
                    yra = 1
                if yra == 0:
                    cur2.execute("""insert into spub2 (id_rec,id_sdok,id_prk,id_snd,kiekis,parkn,pvmproc,pvm,vnt,uzs_prkkod,comment,pvm_kod) values (GEN_ID(id_apv_gen,1),(select first 1 id_sdok from sdok where doknr=? or doknr2=?),coalesce((select first 1 id_prk from prk where trim(kod)=? ),-1),
                                                1345,?,?,21,?,'vnt.',?,?,'PVM1')""",
                             [doknr,doknr,kodas, kiekis0, kaina, suma * 1.21 - suma, kodas,inf])
                cur2.execute("""insert into prk_rez (id,id_dok,id_sdok,id_prk,id_snd,kiekis,rez_type,author,terminas) values (GEN_ID(id_snd_gen,1),-1,(select first 1 id_sdok from sdok where doknr=? or doknr2=?),coalesce((select first 1 id_prk from prk where trim(kod)=? ),-1),
                                                          1345,?,4,?,?+10)""", [doknr,doknr,kodas, kiekis0, vartot, dt2])
            kiek = 0
            cur.execute("""select sum(kiekis1) from trmorder where id_trmprk=? and status<200""", [idprk])
            for row in cur.fetchall():
                kiek = row[0]
            cur2.execute("""select coalesce(sum(p.kiekis),0)  from prk p where trim(p.kod)=? and p.id_snd=1345 """, [kodas])
            for row2 in cur2.fetchall():
                if row2[0] - kiek > 0:
                    kiek = row2[0] - kiek
                    if kiek <= rezkiekis:
                        rezkiekis = rezkiekis - kiek

                    else:
                        kiek = rezkiekis
                        rezkiekis = 0
                    cur.execute("""update trmorder set status=1, kiekis1=kiekis1+? where id_trmapv=? """, [kiek, idapv])



        if rezkiekis > 0:
            cur.execute(
                """select id_trmapv,coalesce(abs(kiekis0),0) from trmapv where id_trmapvo=? and char_length(muitkod_rf)>8""",
                [idapv])
            yra = 0
            kiek = 0
            for row in cur.fetchall():
                yra = 1
                if row[1] <= rezkiekis:
                    kiek = row[1]
                    rezkiekis = rezkiekis - kiek
                else:
                    kiek = rezkiekis
                    rezkiekis = 0
                if yra > 0:
                    cur.execute("""update trmorder set kiekis2=?, status=1 where id_trmapv=? """, [kiek, idapv])


        if rezkiekis > 0:
            cur.execute(
                """select id_trmapv,coalesce(abs(kiekis0),0) from trmapv where id_trmapvo=? and char_length(muitkod_rf)<=8""",
                [idapv])
            yra = 0
            kiek = 0
            for row in cur.fetchall():
                yra = 1
                if row[1] <= rezkiekis:
                    kiek = row[1]
                    rezkiekis = rezkiekis - kiek
                else:
                    kiek = rezkiekis
                    rezkiekis = 0
                if yra > 0:
                    cur.execute("""update trmorder set kiekis3=?, status=1 where id_trmapv=? """, [kiek, idapv])



    while True and rezkiekis > 0:
        lik = 0
        kelyje = 0
        idapv0 = -1
        ipak = 1
        idprk = -1
        inspkiekis = 0
        cur.execute("""select first 1 a.id_trmapv0,a.kiekis,a.pkiekis,a.likutis-a.rezervuota,a.muitkod_lt,a.muitkod_rf,p.id_trmprk from trmapv a left join trmprk p on a.id_trmprk=p.id_trmprk
                 where char_length(a.muitkod_rf)>8 and p.kod=? and a.likutis-a.rezervuota>0 and a.tip=0 """, [kodas])
        for row in cur.fetchall():
            yra = 1
            idapv0 = row[0]
            lik = row[3]
            ipak = row[1] / row[2]
            muitkodlt = row[4]
            muitkodrf = row[5]
            idprk = row[6]
            if rezkiekis <= lik:
                inspkiekis = math.ceil(rezkiekis / ipak)
                kiekis4 = rezkiekis
            else:
                inspkiekis = math.ceil(lik / ipak)
                kiekis4 = lik
        if yra == 0:
            cur.execute(
                """select first 1 a.id_trmapv0,a.kiekis,a.pkiekis,a.likutis-a.rezervuota,a.muitkod_lt,a.muitkod_rf,p.id_trmprk from trmapv a left join trmprk p on a.id_trmprk=p.id_trmprk
                    where char_length(a.muitkod_rf)<=8 and p.kod=? and a.likutis-a.rezervuota>0 and a.tip=0 """, [kodas])
            for row in cur.fetchall():
                yra = 1
                idapv0 = row[0]
                lik = row[3]
                ipak = row[1] / row[2]
                muitkodlt = row[4]
                muitkodrf = row[5]
                idprk = row[6]
                if rezkiekis <= lik:
                    inspkiekis = math.ceil(rezkiekis / ipak)
                    kiekis4 = rezkiekis
                else:
                    inspkiekis = math.ceil(lik / ipak)
                    kiekis4 = lik
        if yra == 0:

            cur.execute(
                """select first 1 a1.id_trmapv0,a1.kiekis0,a1.pkiekis0,a1.kiekis0-a1.rezervuota,muitkod_lt,muitkod_rf,p.id_trmprk from trmapv a1 left join trmdok d1 on a1.id_trmdok=d1.id_trmdok left join trmprk p on p.id_trmprk=a1.id_trmprk where p.kod=? and a1.kiekis=0 and a1.OPTIP=2 and d1.sutvarkyta='N'
                and d1.data_iskr is null and a1.kiekis0-a1.rezervuota>0 """, [kodas])
            for row in cur.fetchall():
                yra = 1
                idapv0 = row[0]
                lik = row[3]
                kelyje = lik
                kiekis4 = 0
                ipak = row[1] / row[2]
                muitkodlt = row[4]
                muitkodrf = row[5]
                idprk = row[6]
                if rezkiekis <= lik:
                    inspkiekis = math.ceil(rezkiekis / ipak)
                    kiekis4 = rezkiekis
                else:
                    inspkiekis = math.ceil(lik / ipak)
                    kiekis4 = lik

        if inspkiekis > 0 and lik > 0:
            memo = str(doknr)+' '+klpavad+' '+str(rezkiekis)+' pcs.'
            cur.execute(
                """insert into trmapv (id_trmapv,id_trmapv0,id_trmprk,id_trmdok,id_trmapvo,kiekis0,pkiekis0,optip,vartot,muitkod_lt,muitkod_rf,memo) values (GEN_ID(id_apv_gen,1),?,?,?,?,?,?,4,?,?,?,?) """,
                [idapv0, idprk, iddok, idapv, -inspkiekis * ipak, -inspkiekis, vartot, muitkodlt, muitkodrf,memo])
            if len(muitkodrf) > 8 and kelyje == 0:
                cur.execute("""update trmorder set status=1,kiekis2=kiekis2+? where id_trmapv=? """, [kiekis4, idapv])
            elif len(muitkodrf) <= 8 and kelyje == 0:
                cur.execute("""update trmorder set status=1,kiekis3=kiekis3+? where id_trmapv=? """, [kiekis4, idapv])
            else:
                cur.execute("""update trmorder set status=1,kiekis4=kiekis4+? where id_trmapv=? """, [kiekis4, idapv])

        if rezkiekis <= lik:
            rezkiekis = 0
        else:
            rezkiekis = rezkiekis - lik
        if yra == 0:
            rezkiekis = 0
        else:
            yra = 0
        if rezkiekis == 0:
            break

    con.commit()
    con2.commit()


def customs(request):
 if request.user.groups.filter(name='Admins').exists():
   imone = request.user.first_name
   rkod = ''
   klpavad = ''
   vartot = request.user.username
   tx = ''
   if request.user.first_name == 'admin':
      tx = "where p.aktyvi='Y' and p.tip=? and ((d.DATA_PAKR between ? and ?) or (o.status in (1,2)))"
      imone=0
   else:
      tx = "where p.aktyvi='Y' and p.tip=0  and trim(k.rkod)=? and ((d.DATA_PAKR between ? and ?) or (o.status<1))"
   idprk = -1
   kodas = ''

   con = kinterbasdb.connect(dsn='firebird-pc.latgrupe.eu:Luckust', user='sysdba', password='masterkey', charset='UTF8')
   cur = con.cursor()
   con2 = kinterbasdb.connect(dsn='firebird-pc.latgrupe.eu:ClaraLux', user='sysdba', password='masterkey', charset='WIN1257')
   cur2 = con2.cursor()

   cur.execute("""select distinct d.eilnr,d.DATA_PAKR, p.KOD || ' ' || c.pavad item,o.kiekis0,
      coalesce(o.kiekis1+o.kiekis2+o.kiekis3+o.kiekis4,0) rez,
      o.status pdata,o.KAINA,o.kaina*o.KIEKIS0 suma,iif(o.STATUS<1,'Open',iif(o.status=200,'Invoiced','Execute')) status,k.pavad,o.id_trmapv,o.id_trmprk,d.id_trmdok
      ,o.kiekis1,iif(kiekis1>0,cast(cast('now' as date) as varchar(10)),'-') dt1  
      ,o.kiekis2,iif(kiekis2>0,cast(cast(o.modify_date as date)+5 as varchar(10)),'-') dt2
      ,o.kiekis3,iif(kiekis3>0,cast(cast(o.modify_date as date)+7 as varchar(10)),'-') dt3
      ,o.kiekis4,iif(kiekis4>0,cast((select first 1 cast(d1.data_pakr+60 as date) from trmapv a1 left join trmdok d1 on a1.id_trmdok=d1.id_trmdok where a1.ID_TRMPRK=o.id_trmprk and a1.kiekis=0 and a1.OPTIP=2 and d1.sutvarkyta='N' and d1.data_iskr is null) as varchar(10)),'-') dt4 
      ,o.id_kladr,k.id_trmkl,coalesce(r.kod,''),coalesce(r.adr,''),coalesce(r.pindex,''),coalesce(r.salis,''),o.pkiekis
      from trmdok d left join trmorder o on d.id_trmdok=o.id_trmdok left join trmprk p on p.id_trmprk=o.id_trmprk 
      left join trmdict c on p.id_txt6=c.id_trmdict left join trmkl k on k.ID_trmKL=d.ID_KL left join trmkladr r on o.id_kladr=r.id_trmadr          
      where o.status in (1,2) and (kiekis2>0 or kiekis3>0) order by o.id_trmapv""")
   result_list = []

   for row in cur.fetchall():

      p = {'nr': row[0], 'data': row[1], 'item': row[2], 'kiekis': row[3], 'rez': row[4], 'pdata': row[5], 'kaina': row[6], 'suma': row[7], 'status': row[8], 'klpavad':row[9], 'idapv':row[10], 'idprk':row[11],
           'iddok':row[12], 'kiekis1':row[13], 'dt1':row[14], 'kiekis2':row[15], 'dt2':row[16], 'kiekis3':row[17], 'dt3':row[18], 'kiekis4':row[19], 'dt4':row[20], 'uzskiekis':row[3]-row[4], 'id_kladr':row[21]
           , 'id_trmkl':row[22], 'adrkod':row[23], 'adr':row[24], 'index':row[25], 'salis':row[26], 'pkiekis':row[27]}
      result_list.append(p)

   return render(request, 'customs.html', {'result_list': result_list})
 else:
     return render(request, 'index.html' )
def export_customs_xls(request):
 if request.user.groups.filter(name='Admins').exists():
    response = HttpResponse(content_type='application/ms-excel')
    response['Content-Disposition'] = 'attachment; filename="customs.xls"'

    wb = xlwt.Workbook(encoding='utf-8')
    ws = wb.add_sheet('Customs')

    # Sheet header, first row
    row_num = 0

    font_style = xlwt.XFStyle()
    font_style.font.bold = True

    columns = ['Order No.', 'Customer name', 'Product description', 'Quantity', 'Direction', 'User']

    for col_num in range(len(columns)):
        ws.write(row_num, col_num, columns[col_num], font_style)

    # Sheet body, remaining rows
    font_style = xlwt.XFStyle()
    con = kinterbasdb.connect(dsn='firebird-pc.latgrupe.eu:Luckust', user='sysdba', password='masterkey', charset='UTF8')
    cur = con.cursor()

    cur.execute("""select d.eilnr,k.pavad,p.kod,o.kiekis,iif(o.status=1,'Siauliai','Ryga'),o.vartot from trmdok d left join trmorder o on d.id_trmdok=o.id_trmdok left join trmprk p on p.id_trmprk=o.id_trmprk 
                left join trmkl k on k.ID_trmKL=d.ID_KL where o.status in (1,2) and (kiekis2>0 or kiekis3>0) order by o.id_trmapv  """)
    for row in cur.fetchall():
         row_num += 1
         for col_num in range(len(row)):
             ws.write(row_num, col_num, row[col_num], font_style)

    wb.save(response)
    return response
 else:
     return render(request, 'index.html' )
def home_view(request):
    if request.user.is_authenticated():
        template_name = 'home.html'
        # context = {
        #     "kodas": client,
        #     "is_rus": len(request.user.groups.all()) > 0
        # }
        return render(request, template_name)
    else:
        return redirect('login')

