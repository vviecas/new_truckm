"""truckm URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""

# urlpatterns = [
#     path('admin/', admin.site.urls),
# ]


from django.contrib import admin
from django.urls import path
from django.conf.urls import url, include
from django.views.generic.base import TemplateView
from truckm.views import dok_list, export_dok_xls,get_dok, home_view, trmprk_list, export_trmprk_xls, clop_list, export_clop_xls, clprk_list, export_clprk_xls,clop_detail,export_clop_detail_xls,\
     cart_items,export_cart_xls,orders,orders_admin,export_orders_xls,check_orders,order_confirm,customs,export_customs_xls


urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/', include('django.contrib.auth.urls')),
    path('', TemplateView.as_view(template_name='index.html'), name='home'),
    # path('', TemplateView.as_view(template_name='truckmpard.html'), name='dok_list'),
    # path('trmprk/', TemplateView.as_view(template_name='trmprk.html'), name='trm_prklist'),
    url(r'^dok/$', dok_list, name='dok_list'),
    # url(r'^dok/from/(?P<d>[0-9-]+)/to/(?P<d2>[0-9-]+)/$',dok_list),
    url(r'^trmprk/$', trmprk_list),
    url(r'^clop/$', clop_list),
    url(r'^clop_detail/(?P<iddok>[0-9- ]+)/$', clop_detail),
    url(r'^clprk/$', clprk_list),
    # url(r'^/from/(?P<d>[0-9-]+)/to/(?P<d2>[0-9-]+)/$', dok_list, name="dok_list"),
    url(r'^export_dok_xls/(?P<sndkod>.+?)/(?P<nuo>[0-9- ]+)/(?P<iki>[0-9- ]+)/$', export_dok_xls, name='export_dok_xls'),
    url(r'^export/trmprk/$', export_trmprk_xls, name='export_trmprk_xls'),
    url(r'^export_clop_xls/(?P<nuo>[0-9- ]+)/(?P<iki>[0-9- ]+)/$', export_clop_xls, name='export_clop_xls'),
    url(r'^export_clop_detail_xls/(?P<nuo>[0-9- ]+)/(?P<iki>[0-9- ]+)/$', export_clop_detail_xls, name='export_clop_detail_xls'),
    url(r'^export/clprk/$', export_clprk_xls, name='export_clprk_xls'),
    url(r'^get-dok/(?P<id>[0-9- ]+)/(?P<tip>[0-9- ]+)/(?P<doknr>[-\w]+)/$', get_dok,name='get_dok'),
    url(r'^cart_items/$', cart_items, name='cart_items'),
    url(r'^export/cart/$', export_cart_xls, name='export_cart_xls'),
    url(r'^orders/$', orders, name='orders'),
    url(r'^orders_admin/$', orders_admin, name='orders_admin'),
    url(r'^export/orders/$', export_orders_xls, name='export_orders_xls'),
    url(r'^checkorders/$', check_orders),
    url(r'^order_confirm/$', order_confirm, name='order_confirm'),
    url(r'^customs/$', customs, name='customs'),
    url(r'^export/customs/$', export_customs_xls, name='export_customs_xls'),

]

