from bootstrap_datepicker_plus import DatePickerInput


class ToDoForm(forms.Form):
    date = forms.DateField(
        widget=DatePickerInput(
            options={
                "format": "yyyy/mm/dd",
                "autoclose": True
            }
        )
    )